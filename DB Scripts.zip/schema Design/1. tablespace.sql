---For IMS----

create tablespace ENRICH_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ENRICH_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace ENRICH_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ENRICH_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace TRANS_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/TRANS_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace TRANS_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/TRANS_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace CONFIG_DATA 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CONFIG_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace CONFIG_INDX 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CONFIG_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace TRANS_SWIFT_DATA 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/TRANS_SWIFT_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace TRANS_SWIFT_INDX 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/TRANS_SWIFT_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace TRANS_FIX_DATA 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/TRANS_FIX_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace TRANS_FIX_INDX 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/TRANS_FIX_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace TRANS_MSG_DATA 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/TRANS_MSG_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace TRANS_MSG_INDX 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/TRANS_MSG_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace TRANS_VENDOR_DATA 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/TRANS_VENDOR_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace TRANS_VENDOR_INDX 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/TRANS_VENDOR_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace COMPLIANCE_DATA 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/COMPLIANCE_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace COMPLIANCE_INDX 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/COMPLIANCE_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace CRT_MANUAL_DATA 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CRT_MANUAL_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace CRT_MANUAL_INDX 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CRT_MANUAL_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_TABLES_DATA
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_TABLES_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace IMS_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace IMS_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace IMS_DASH_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_DASH_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_DASH_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_DASH_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_DASH_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_DASH_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RENT_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RENT_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RENT_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RENT_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RENT_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RENT_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_DOCS_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_DOCS_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_DOCS_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_DOCS_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_DOCS_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_DOCS_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;



create tablespace PREPRO_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/PREPRO_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace PREPRO_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/PREPRO_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace PREPRO_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/PREPRO_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace ACH_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ACH_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace ACH_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ACH_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace ACH_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ACH_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace ACH_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ACH_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace ACH_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ACH_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;






---For mymt---

create tablespace IMS_MM_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_MM_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_MM_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_MM_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace MM_CONFIG_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/MM_CONFIG_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace MM_CONFIG_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/MM_CONFIG_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_MM_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_MM_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_MM_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_MM_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_MM_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_MM_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace CORP_DATA
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CORP_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace CORP_ACT 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CORP_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace CORP_LIVE 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CORP_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace CORP_ARC 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CORP_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace CORP_INDX 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CORP_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace NACHA_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/NACHA_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace NACHA_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/NACHA_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace NACHA_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/NACHA_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace MANDATE_DATA
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/MANDATE_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace MANDATE_ACT 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/MANDATE_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace MANDATE_LIVE 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/MANDATE_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace MANDATE_ARC 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/MANDATE_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace MANDATE_INDX 
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/MANDATE_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTGS_MT_ACT
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTGS_MT_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTGS_MT_ARC
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTGS_MT_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTGS_MT_INDX
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTGS_MT_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTGS_MT_LIVE
Datafile '+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTGS_MT_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;
--For sett---

create tablespace ims_sm_tbs Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ims_sm_tbs.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace ims_sm_tbs_idx Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ims_sm_tbs_idx.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace sm_config_tbs Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/sm_config_tbs.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace sm_config_tbs_idx Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/sm_config_tbs_idx.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_SM_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_SM_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace IMS_SM_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_SM_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_SM_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_SM_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

---For CT----

create tablespace CT_CONFIG_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CT_CONFIG_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace CT_CONFIG_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/CT_CONFIG_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace ENRICH_CT_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ENRICH_CT_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace ENRICH_CT_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/ENRICH_CT_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_CT_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_CT_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_CT_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_CT_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_CT_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_CT_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_CT_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_CT_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_CT_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_CT_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

-------------------recon--------------------------


create tablespace RECON_CONFIG_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RECON_CONFIG_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RECON_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RECON_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RECON_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RECON_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RECON_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RECON_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RECON_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RECON_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RECON_CONFIG_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RECON_CONFIG_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RECON_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RECON_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

--------------IMS_RPT--------

create tablespace IMS_RPT_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RPT_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace IMS_RPT_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RPT_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RPT_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RPT_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RPT_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RPT_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RPT_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RPT_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

---fpx---


create tablespace FPX_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/FPX_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace FPX_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/FPX_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace FPX_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/FPX_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace FPX_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/FPX_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace FPX_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/FPX_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;




------------IMS_RPP_DATA-----------------------------------

create tablespace IMS_RPP_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RPP_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace IMS_RPP_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RPP_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RPP_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RPP_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RPP_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RPP_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_RPP_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_RPP_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;




------------RTP-----------------------------------

create tablespace RTP_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace RTP_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTP_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTP_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTP_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;



------------RTGS-----------------------------------

create tablespace RTGS_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTGS_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace RTGS_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTGS_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTGS_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTGS_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTGS_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTGS_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTGS_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTGS_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;



------------IMS_IF-----------------------------------

create tablespace IMS_IF_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_IF_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace IMS_IF_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_IF_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_IF_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_IF_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_IF_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_IF_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_IF_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_IF_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;




------------WPS-----------------------------------

create tablespace WPS_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/WPS_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace WPS_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/WPS_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace WPS_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/WPS_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace WPS_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/WPS_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace WPS_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/WPS_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;






------------RTP1-----------------------------------

create tablespace RTP1_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP1_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace RTP1_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP1_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTP1_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP1_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTP1_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP1_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTP1_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP1_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

------------RTP2-----------------------------------

create tablespace RTP2_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP2_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace RTP2_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP2_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTP2_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP2_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTP2_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP2_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTP2_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTP2_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

------------IMS_BH-----------------------------------

create tablespace IMS_BH Datafile
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_BH.DBF'
size 10m
autoextend on
next 10m
maxsize unlimited;


create tablespace IMS_BC_LIVE Datafile
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_BC_LIVE.DBF'
size 10m
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_BC_ARC Datafile
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_BC_ARC.DBF'
size 10m
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_BC_ACT Datafile
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_BC_ACT.DBF'
size 10m
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_BC_INDX Datafile
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_BC_INDX.DBF'
size 10m
autoextend on
next 10m
maxsize unlimited;




------------IMS_BH-----------------------------------

create tablespace IMS_BH_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_BH_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;


create tablespace IMS_BH_LIVE Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_BH_LIVE.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_BH_ARC Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_BH_ARC.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_BH_ACT Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_BH_ACT.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_BH_INDX Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_BH_INDX.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace RTGS_MT_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/RTGS_MT_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace IMS_SM_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/IMS_SM_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;

create tablespace SM_CONFIG_DATA Datafile 
'+DATA/IMS/30D3EC4A8A9BD69CE063194DA8C032E3/DATAFILE/SM_CONFIG_DATA.DBF'
size 10m 
autoextend on
next 10m
maxsize unlimited;





