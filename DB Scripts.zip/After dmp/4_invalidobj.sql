CREATE OR REPLACE PROCEDURE sys.PROC_COMPILE_INVALID_OBJECTS
IS
   CURSOR cur
   IS
      SELECT owner, object_name, object_type
        FROM sys.dba_objects
       WHERE     object_type IN ('VIEW', 'PROCEDURE', 'FUNCTION')
             AND status <> 'VALID'
             AND OWNER IN ('ENRICH','TRANS','CONFIG','COMPLIANCE','CRT_MANUAL','IMS_TABLES','IMS_DOCS','RTGS_MT','MM_CONFIG','IMS_MM','IMS_RECON','RECON_CONFIG','AMBANKADMIN','FPX','MANDATE','RTP2','IMS_RPT','RTP1','IMSTOOLS','IMS_IF','RTP','RTGS','IMS_RPP','WPS','DATA_VLDTN');
BEGIN
   FOR cur_rec IN cur
   LOOP
      BEGIN
         EXECUTE IMMEDIATE
               'ALTER '
            || cur_rec.object_type
            || ' "'
            || cur_rec.owner
            || '"."'
            || cur_rec.object_name
            || '" COMPILE';
      EXCEPTION
         WHEN OTHERS
         THEN
            DBMS_OUTPUT.put_line (
                  cur_rec.object_type
               || ' : '
               || cur_rec.owner
               || ' : '
               || cur_rec.object_name);
      END;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      COMMIT;
END;
/

BEGIN
 SYS.PROC_COMPILE_INVALID_OBJECTS;	
END;
/
commit;






