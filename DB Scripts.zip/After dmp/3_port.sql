update config.SERVICES set PROVIDER_URL='t3://localhost:7001/'  where SERVICE_ID=2;
update config.LISTENER_PARAMS set PROVIDER_URL='t3://localhost:7001/';
update config.MDB_CONNECTION set PROVIDER_URL='t3://localhost:7001/';
update config.REPORTS_SERVICES set PROVIDER_URL='t3://localhost:7001/';
update config.ROUTINE_PARAMS set PROVIDER_URL='t3://localhost:7001/';
update config.ROUTINE_RUNNER_PARAMS set PROVIDER_URL='t3://localhost:7001/';
update config.REPORTS_SERVICES set PROVIDER_URL='t3://localhost:7001/';
update CT_CONFIG.SERVICES set PROVIDER_URL='t3://localhost:7001/'  where SERVICE_ID=2;
update SM_CONFIG.SERVICES set PROVIDER_URL='t3://localhost:7001/'  where SERVICE_ID=2;
update mm_config.SERVICES set PROVIDER_URL='t3://localhost:7001/';
commit;

