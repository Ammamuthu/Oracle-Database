truncate table trans.EMAIL_HISTORY_DTLS;
alter table TRANS.EMAIL_HISTORY_DTLS disable constraint FK_EMAIL_HISTORY_ID;
alter table TRANS.EMAIL_HISTORY disable constraint PK_EMAIL_HISTORY_ID;
truncate table trans.EMAIL_HISTORY;
alter table TRANS.EMAIL_HISTORY enable constraint PK_EMAIL_HISTORY_ID;
alter table TRANS.EMAIL_HISTORY_DTLS enable constraint FK_EMAIL_HISTORY_ID;
commit;

