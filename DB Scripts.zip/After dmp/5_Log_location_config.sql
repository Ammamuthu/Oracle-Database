update CONFIG.ENV_PARAMS set PARAM_VALUE='/u01/app/bea_14_1/user_projects/domains/RPP/logs/imslogs' where PARAM_NAME='LOG_LOCATION';
update CONFIG.ENV_SETTINGS set LOG_LOCATION='/u01/app/bea_14_1/user_projects/domains/RPP/logs/imslogs';
commit;
update CT_CONFIG.ENV_SETTINGS set LOG_LOCATION='/u01/app/bea_14_1/user_projects/domains/RPP/logs/ctlogs';
commit;
update MM_CONFIG.ENV_SETTINGS set LOG_LOCATION='/u01/app/bea_14_1/user_projects/domains/RPP/logs/mymtlogs';
commit;
update SM_CONFIG.ENV_SETTINGS set LOG_LOCATION='/u01/app/bea_14_1/user_projects/domains/RPP/logs/settlogs';
commit;
