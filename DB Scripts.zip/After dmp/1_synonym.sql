
   select 'create or replace public synonym ' || synonym_name ||' for ' || table_owner || '.' || table_name || ';'
      from dba_synonyms where owner = 'PUBLIC'
      and table_owner in ('IMSTOOLS','FPX','TRANS','CONFIG','ENRICH','COMPLIANCE','CRT_MANUAL','IMS_TABLES','IMS_DOCS','IMS_MM','MM_CONFIG','ACH','MANDATE','RTGS_MT','IMS_SM','SM_CONFIG','IMS_CT','CT_CONFIG','ENRICH_CT','IMS_RECON','RECON_CONFIG','IMS_RPT','IMS_IF','RTP','RTGS','IMS_RPP','WPS','IMS_BH','NIMS_MCXBS','NIMS_RIPPLE','NIMS_VISAB2B','RTP2','RTP1');
